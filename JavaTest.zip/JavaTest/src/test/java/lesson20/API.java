package lesson20;


import io.qameta.allure.Step;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class API {
    String url = "http://api.chucknorris.io/jokes";
    public static RequestSpecification request;
    public Response response;
    JsonPath js;


    @BeforeClass
    public void start() {
        RestAssured.baseURI = url;
        request = RestAssured.given();


    }

    @Test
    public void findCategory() {
        response = request.get(url + "/categories");
        js = response.jsonPath();
        List<String> allCategory = js.getList("");
        for (String category : allCategory) {

            System.out.println(category);
        }
    }

    @Step
    public int sumObama() {
        response = request.get(url + "/search?query=Barack Obama");
        js = response.jsonPath();
        List<String> sumObama = js.getList("result");
        return sumObama.size();


    }


    @Step
    public int sumCharlie() {
        response = request.get(url + "/search?query=Charlie Sheen");
        js = response.jsonPath();
        List<String> sumObama = js.getList("result");
        return sumObama.size();


    }

    @Test
    public void moreJoke() {
        int ObamaJok = sumObama();
        int CharlieJoke = sumCharlie();
        if (ObamaJok == CharlieJoke)
            System.out.println("The number of jokes by Obama and Charlie is equal");
        else if (ObamaJok > CharlieJoke)
            System.out.println("Obama's number of jokes is greater than Charlie's");
        else
            System.out.println("The number of Charlie's jokes is greater than Obama's");
    }
}