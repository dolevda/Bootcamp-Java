package lesson20;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class PageMortgage {
    @FindBy(how = How.XPATH, using = "//*[name()='g']//*[@class='highcharts-series highcharts-series-0 highcharts-column-series highcharts-tracker']//*[name()='rect']")
    public List<WebElement> years_table;

    @FindBy(how = How.XPATH, using = "//div//*[name()='svg'][1]//*[name()='path'][@fill='#0D3548']")
    public List<WebElement> pointData;

    @FindBy(how = How.XPATH ,using = "//*[name()='svg']//*[name()='g'][12]//*[name()='text']")
    public List<WebElement> textData;
}
