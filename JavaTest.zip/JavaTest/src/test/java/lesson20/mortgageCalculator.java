package lesson20;

import com.google.common.util.concurrent.Uninterruptibles;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.annotation.Repeatable;
import java.sql.Time;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class mortgageCalculator {

    WebDriver driver;
    PageMortgage mortgage;
    List<WebElement> temp;
    Actions action;

    @BeforeClass
    public void startSession() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.mortgagecalculator.org/");
        mortgage = PageFactory.initElements(driver,PageMortgage.class);
        action = new Actions(driver);
        Uninterruptibles.sleepUninterruptibly(4, TimeUnit.SECONDS);

    }

    @AfterClass
    public void closeSession() {
        driver.quit();

    }


    @Test
    public void printYears(){

        System.out.println("The number of years in the table:"+mortgage.years_table.size());

    }

    @Test
    public void dateYears(){
        for(WebElement point:mortgage.pointData){
           action.moveToElement(point).build().perform();
           System.out.println(mortgage.textData);



        }
        }





}
